// ============================================================
// YOUR DESTINY — PROMO CONFIGURATION
// ============================================================
// Change ONLY the values below when you publish a new promo code.
// Existing VIP activations keep their original 30-day expiration.
// The previous code immediately becomes invalid for NEW activations.

const PROMO_CONFIG = {
  code: 'DESTINY2026',
  durationDays: 30
};
