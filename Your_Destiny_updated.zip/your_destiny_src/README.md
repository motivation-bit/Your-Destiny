# YOUR DESTINY — updated project

## Promo code
Open `promo-config.js` and change:

```js
const PROMO_CONFIG = {
  code: 'DESTINY2026',
  durationDays: 30
};
```

Only this code can create a new VIP activation. Existing VIP activations keep their original expiration date, even after the code is changed.

## Language
Telegram WebApp language has priority. Russian and Spanish are selected automatically when Telegram reports `ru*` or `es*`; every other language falls back to English.

## First visit
The first launch timestamp is stored in `localStorage` as `first_visit_at` and is displayed in Time Capsule. Reset Progress does not remove it.

## Theme order
Royal Purple → Midnight Sapphire → Crimson Curtain → Emerald Forest → Amber Twilight → Kaleidoscope.

Kaleidoscope continuously cycles the available palette.
